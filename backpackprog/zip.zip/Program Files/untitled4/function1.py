def  sayhello():
   print("привет мир")
# блок, принадлежащий функции
# Конец функции

sayhello()
sayhello()
