while True :
    s = input('ведите что не будь')
    if s == 'exit':
        break
    if len(s) == 3:
        print('мало')
        continue
    print("достаточная длина")
# Разные другие действия здесь.