age = 19
name = "arsen"

print('age {0} name {1}' . format(age, name))
print('aa {0}  {1}' .format(name, age))