def maximum(x, y,) :
    if x > y :
        return x
    elif x == y:
        return "числа равны."
    else :
        return y

print(maximum(2, 3))