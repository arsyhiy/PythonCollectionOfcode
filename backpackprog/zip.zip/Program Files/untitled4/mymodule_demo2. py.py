from mymodule import sayhi, __version__

sayhi()
print('версия', __version__)