while True:
    s = input('ведите что небудь')
    if s == 'выход':
        break
    if s == 'гамбит':
         print('деда')
         break
    print('длина строки', len(s))
print('завершение')
