length = 5
breadth = 2
area = length * breadth
print('площадь равна ' , area)
print('Периметр равен', 2 * (length + breadth))
