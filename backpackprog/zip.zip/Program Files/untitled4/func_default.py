def say(message, times = 1):
    print(message * times)

say('привет')
say('мир', 5)