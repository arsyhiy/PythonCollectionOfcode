def printma(a,b):
    if a> b :
        print(a,'максимально')
    elif a == b :
        print(a, 'ravno' , b)
    else :
        print(b, 'maksimalno' )
printma(3, 4)

x= 7
y= 5

printma(x, y)