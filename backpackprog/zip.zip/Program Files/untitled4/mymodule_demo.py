import mymodule

mymodule.sayhi()
print('версия', mymodule. __version__)