number = 23
running = True

while running :
    quess = int(input('напешите число'))

    if quess == number:
     print('верное число')
     running = False  # это останавливает цикл while
    elif guess < number:
     print('Нет, загаданное число немного больше этого.')
    else:
     print('Нет, загаданное число немного меньше этого.')
else:
 print('Цикл while закончен.')
     # Здесь можете выполнить всё что вам ещё нужно
print('Завершение.')
